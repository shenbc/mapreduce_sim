from os import link


class Link:
    def __init__(self, ID, model, begin, end, capacity):
        self.ID = ID
        self.role = "link"
        self.model = model
        self.capacity = capacity
        self.begin = begin
        self.end = end
        self.is_before_spine = False
        self.worker_pass_list = []
        if(self.begin.role=="worker" and self.end.role=="leaf") or (self.begin.role=="leaf" and self.end.role=="spine"):
            self.is_before_spine = True
    
    def addworker(self, worker):
        if worker not in self.worker_pass_list:
            self.worker_pass_list.add(worker)
