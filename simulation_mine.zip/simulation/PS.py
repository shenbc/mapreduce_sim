class PS:
    def __init__(self, ID, model, capacity):
        self.ID = ID
        self.role = "ps"
        self.model = model
        self.worker_list = []
        self.capacity = capacity

    def addworker(self, worker):
        if worker not in self.worker_list:
            self.worker_list.add(worker)
