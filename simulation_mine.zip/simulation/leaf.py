class Leaf:
    def __init__(self, ID):
        self.ID = ID
        self.role = "leaf"