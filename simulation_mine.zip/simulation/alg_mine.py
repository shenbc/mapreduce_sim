import pulp
simplify_flag = False


def MINE(worker_set, spine_set, model_set, link_set):
    # 创建模型
    prob_mine = pulp.LpProblem("MINE", pulp.LpMinimize)

    # x是0-1变量,y是0-1变量,z是0-1变量, lambda是连续变量
    # w的梯度是否经过s
    variables_X_s_w = []
    # w的梯度是否在s上聚合
    variables_Y_s_w = []
    # s上k类的聚合次数
    variables_alpha_s_k = []
    # s上是否发生k类聚合
    variables_beta_s_k = []

    for s in spine_set:
        for w in worker_set:
            variables_X_s_w.append(pulp.LpVariable(
                'X_s' + str(s.ID) + '_w' + str(w.ID), cat=pulp.LpBinary))
            variables_Y_s_w.append(pulp.LpVariable(
                'Y_s' + str(s.ID) + '_w' + str(w.ID), cat=pulp.LpBinary))
        for k in model_set:
            variables_alpha_s_k.append(pulp.LpVariable(
                'Alpha_s' + str(s.ID) + '_k' + str(k.ID), lowBound=0, cat=pulp.LpInteger))
            variables_beta_s_k.append(pulp.LpVariable(
                'Beta_s' + str(s.ID) + '_k' + str(k.ID), cat=pulp.LpBinary))
    variable_lambda = pulp.LpVariable(
        'lambda', lowBound=0, upBound=1, cat=pulp.LpContinuous)

    # 添加目标函数
    prob_mine += variable_lambda, "min lambda"

    # 不等式1 y与x的关系
    for s in spine_set:
        for w in worker_set:
            prob_mine += variables_Y_s_w[s.ID * len(
                spine_set) + w.ID] <= variables_X_s_w[s.ID * len(spine_set) + w.ID]

    # 是否使用化简后的问题定义
    if simplify_flag:
        # 不等式2 alpha与y的关系
        for s in spine_set:
            for k in model_set:
                sum_Y_s_w = 0
                for w in worker_set:
                    if w.model == k:
                        sum_Y_s_w += variables_Y_s_w[s.ID *
                                                     len(spine_set) + w.ID]
                prob_mine += variables_alpha_s_k[s.ID *
                                                 len(spine_set) + k.ID] >= sum_Y_s_w - 1

        # 不等式3 beta与y的关系
        for s in spine_set:
            for k in model_set:
                for w in worker_set:
                    if w.model == k:
                        prob_mine += variables_beta_s_k[s.ID * len(
                            spine_set) + k.ID] >= variables_Y_s_w[s.ID * len(spine_set) + w.ID]
    else:
        # 等式2,3 alpha/beta的计算方式
        for s in spine_set:
            for k in model_set:
                sum_Y_s_w = 0
                for w in worker_set:
                    if w.model == k:
                        sum_Y_s_w += variables_Y_s_w[s.ID *
                                                     len(spine_set) + w.ID]
                if sum_Y_s_w <= 1:
                    prob_mine += variables_beta_s_k == sum_Y_s_w
                else:
                    prob_mine += variables_alpha_s_k == 1
                
                sum_Y_s_w -= 1
                if sum_Y_s_w >= 0:
                    prob_mine += variables_alpha_s_k == sum_Y_s_w
                else:
                    prob_mine += variables_alpha_s_k == 0
                    

    # 不等式4 交换机处理能力约束
    for s in spine_set:
        sum_alpha_s_k = 0
        for k in model_set:
            sum_alpha_s_k += variables_alpha_s_k[s.ID *
                                                 len(spine_set) + k.ID] * k.cost
        prob_mine += sum_alpha_s_k <= s.capacity

    # 不等式5 链路带宽约束
    for e in link_set:
        flow = 0
        for s in spine_set:
            for k in model_set:
                for w in worker_set:
                    if w.model == k:
                        # spine前的流量
                        if e.begin == w or e.end == s:
                            flow += k.gradient_trans_rate * \
                                variables_X_s_w[s.ID * len(spine_set) + w.ID]
                        # spine后未聚合的流量
                        if e.begin == s or e.end == k.PS:
                            flow += k.gradient_trans_rate * \
                                (variables_X_s_w[s.ID * len(spine_set) + w.ID] -
                                 variables_Y_s_w[s.ID * len(spine_set) + w.ID])
                # spine未聚合的流量
                if e.begin == s or e.end == k.PS:
                    flow += k.gradient_trans_rate * \
                        variables_beta_s_k[s.ID * len(spine_set) + k.ID]
        prob_mine += flow <= e.capacity * variable_lambda

    # 等式6 路由约束
    for w in worker_set:
        sum_X_s_w = 0
        for s in spine_set:
            sum_X_s_w += variables_X_s_w[s.ID * len(spine_set) + w.ID]
        prob_mine += sum_X_s_w == 1

    prob_mine.solve()

    for var in variables_X_s_w:
        if var.varValue > 0:
            print(var.name, var.varValue)
    for var in variables_Y_s_w:
        if var.varValue > 0:
            print(var.name, var.varValue)
    print(variable_lambda.name, variable_lambda.varValue)
